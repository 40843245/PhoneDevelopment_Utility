package com.example.snackbar_v2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity
{

    private static final String DEBUG_TAG = "DEBUG_TAG";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CreateMySnackbar();
    }
    void CreateMySnackbar()
    {
        MySnackbar mySnackbar;
        View view;
        TextView textView;
        View.OnClickListener onClickListener;

        view=findViewById(R.id.TextView_1);
        textView=findViewById(R.id.TextView_1);

        mySnackbar = new MySnackbar();

        mySnackbar.SetView(view);
        mySnackbar.SetTextView(textView);
        mySnackbar.SetIsContinue(true);
        mySnackbar.SetMessage("SnackBar");
        mySnackbar.SetDuration(Snackbar.LENGTH_INDEFINITE);

        mySnackbar.Make();

        onClickListener=new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mySnackbar.TryToRepeatShow();
            }
        };

        mySnackbar.SetActionText("Undo");
        mySnackbar.SetOnClickListener(onClickListener);
        mySnackbar.SetAction();

        mySnackbar.Show();
    }
}