package com.example.snackbar_v2;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

public class MySnackbar
{
    public Snackbar snackbar;
    public TextView textView;
    public View view;
    public boolean isContinue;
    private View.OnClickListener onClickListener;

    private int clickTimes = -1;

    private  CharSequence actionText;
    private  CharSequence message;
    private int duration;

    void SetIsContinue(
            boolean isContinue
            )
    {
        this.isContinue = isContinue;
    }
    public void SetView(View view)
    {
        this.view=view;
    }
    public void SetTextView(TextView textView)
    {
        this.textView=textView;
    }

    public void SetOnClickListener(
            View.OnClickListener onClickListener
    )
    {
        this.onClickListener = onClickListener;
    }

    public void SetActionText(
            CharSequence actionText
    )
    {
        this.actionText=actionText;
    }
    public void SetMessage(
            CharSequence message
    )
    {
        this.message=message;
    }
    public void SetDuration(
            int duration
    )
    {
        this.duration = duration;
    }

    public void SetAction()
    {
        this.snackbar.setAction(this.actionText,this.onClickListener);
    }

    public void IncrClickTimes()
    {
        if(this.clickTimes < 0 )
        {
            this.clickTimes = 0;
            return;
        }
        this.clickTimes += 1;
    }

    public void Make()
    {
        this.snackbar=Snackbar.make(this.view,this.message,this.duration);
    }
    public void Show()
    {
        this.IncrClickTimes();
        textView.setText("");
        textView.append("You click "+String.valueOf(this.clickTimes)+" times."+"\n");
        this.snackbar.show();
    }

    public void TryToRepeatShow()
    {
        if(this.isContinue == true)
        {
            this.Make();
            this.SetAction();
            this.Show();
        }
    }

}
