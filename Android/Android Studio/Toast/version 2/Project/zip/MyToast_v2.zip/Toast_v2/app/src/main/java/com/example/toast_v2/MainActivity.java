package com.example.toast_v2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    private int counter=0;
    TextView textView_1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MyToast myToast;

        textView_1 = findViewById(R.id.TextView_1);

        myToast = new MyToast();

        myToast.SetMessage("Toast");
        myToast.SetContext(this);
        myToast.SetDuration(Toast.LENGTH_LONG);
        myToast.SetIsContinue(true);

        myToast.Make();
        myToast.SetGravity(1,10,200);

        myToast.SetCallback(new Toast.Callback()
        {
            @Override
            public void onToastShown()
            {
                super.onToastShown();
            }

            @Override
            public void onToastHidden()
            {
                counter += 1;

                super.onToastHidden();
                textView_1.setText("");
                textView_1.append("Toast has shown "+String.valueOf(counter)+" times.");
                textView_1.append("\n");
                myToast.TryRepeatToShow();
            }
        });
        myToast.Show();
    }
}