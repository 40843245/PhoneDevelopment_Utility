package com.example.toast_v2;

import android.content.Context;
import android.widget.Toast;

public class MyToast
{
    private CharSequence message;
    private int duration;
    private int gravity;
    private int offsetX;
    private int offsetY;
    private boolean isContinue;
    private Toast.Callback callback;
    private Context context;
    private Toast toast;


    public void SetMessage(
            CharSequence message
    )
    {
        this.message=message;
    }
    public void SetCallback(
            Toast.Callback callback
    )
    {
        this.callback = callback;
        this.AddCallback();
    }
    public void SetContext(
            Context context
    )
    {
        this.context=context;
    }
    public void SetDuration(
            int duration
    )
    {
        this.duration=duration;
    }

    public void SetIsContinue(
            boolean isContinue
    )
    {
        this.isContinue=isContinue;
    }

    public void SetGravity(
            int gravity,
            int offsetX,
            int offsetY
    )
    {
        this.offsetX=offsetX;
        this.offsetY=offsetY;
        this.gravity=gravity;
        this.SetGravityUtility(this.gravity,this.offsetX,this.offsetY);
    }

    private void SetGravityUtility(
            int gravity,
            int offsetX,
            int offsetY
    )
    {
        this.toast.setGravity(gravity,offsetX,offsetY);
    }

    private void AddCallback()
    {
        this.toast.addCallback(this.callback);
    }
    public void Make()
    {
        this.toast = Toast.makeText(this.context,this.message,this.duration);
    }
    public void Show()
    {
        this.toast.show();
    }

    public void TryRepeatToShow()
    {
        if(this.isContinue == true)
        {
            this.Make();
            this.AddCallback();
            this.Show();
        }
    }
}
